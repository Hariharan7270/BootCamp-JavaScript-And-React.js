import React from "react";

function Note() {
  return (
    <div>
      <h1>An Excavation of the COVID-19 Pandemic</h1>
      <p>
        With over 131 million people fully vaccinated in the U.S. and numbers of
        new infections dropping nationwide, some have started to declare the
        “end” of the pandemic, despite surging cases across much of the world.
      </p>
    </div>
  );
}

export default Note;
