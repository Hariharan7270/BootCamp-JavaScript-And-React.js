import React from "react";

var year = new Date().getFullYear();
function Footer() {
  return (
    <footer>
       copy right @ {year} 
    </footer>
  );
}

export default Footer;
